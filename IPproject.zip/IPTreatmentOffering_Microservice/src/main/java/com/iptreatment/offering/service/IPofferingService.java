package com.iptreatment.offering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iptreatment.offering.data.PackageDetailsRepo;
import com.iptreatment.offering.data.SpecialistDetailsRepo;
import com.iptreatment.offering.entity.InPatientServicePackage;
import com.iptreatment.offering.entity.SpecialistDetail;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@Service
public class IPofferingService {

	
	
	@Autowired
	PackageDetailsRepo detailsRepo;
	
	@Autowired
	SpecialistDetailsRepo repo;
	
	public List<SpecialistDetail> viewAllSpecialist(){
		log.info("Inside IPoffering Service -> viewAllSpecialist");
		return repo.findAll();
	}
	
	public InPatientServicePackage viewPackageByName(String treatmentPackageName){
		log.info("Inside IPoffering Service -> viewPackageByNAme");
		return detailsRepo.findByTreatmentPackageName(treatmentPackageName);
	}
	
	
	public List<InPatientServicePackage> viewPackages(){
		log.info("Inside IPoffering Service -> viewPackages");
		return detailsRepo.findAll();
	}
	
	public SpecialistDetail getSpecialistByPackage(String packageName)
	{
		SpecialistDetail specialist;
		String ailment=detailsRepo.findByTreatmentPackageName(packageName).getAilmentCategory();
		if(packageName.contains("1"))
		{
			specialist=repo.findByAreaOfExpertiseAndExperienceInYearsLessThanEqual(ailment,4);
		}
		else
		{
			specialist=repo.findByAreaOfExpertiseAndExperienceInYearsGreaterThanEqual(ailment,5);
		}
		return specialist;
	}
}

