package com.iptreatment.offering.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.iptreatment.offering.entity.InPatientServicePackage;
import com.iptreatment.offering.entity.SpecialistDetail;
import com.iptreatment.offering.service.IPofferingService;


@RestController
public class OfferingsController {
	
	@Autowired
	IPofferingService ipOfferingService;
	

	@GetMapping("/Specialists")
	public List<SpecialistDetail> viewAllSpecialist(){
		return ipOfferingService.viewAllSpecialist();
	}


	@GetMapping("/IPTreatmentPackages")
	public List<InPatientServicePackage> viewPackages() {
		return ipOfferingService.viewPackages();

	}
	
	@GetMapping("/IPTreatmentPackageByName/{packageName}")
	public InPatientServicePackage viewPackageByName(@PathVariable("packageName") String packageName) {

		return ipOfferingService.viewPackageByName(packageName);
	}
	
	@GetMapping("/IPSpecialist/{packageName}")
	public SpecialistDetail getSpecialistByPackage(@PathVariable("packageName")String packageName) {
		return ipOfferingService.getSpecialistByPackage(packageName);
	}
}
