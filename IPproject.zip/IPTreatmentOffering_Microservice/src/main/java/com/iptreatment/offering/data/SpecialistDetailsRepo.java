package com.iptreatment.offering.data;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.iptreatment.offering.entity.SpecialistDetail;

@Repository
public interface SpecialistDetailsRepo extends JpaRepository<SpecialistDetail, Integer> {

	
	SpecialistDetail findByAreaOfExpertiseAndExperienceInYearsLessThanEqual(String ailment,int year);
	
	SpecialistDetail findByAreaOfExpertiseAndExperienceInYearsGreaterThanEqual(String ailment,int year);
}
