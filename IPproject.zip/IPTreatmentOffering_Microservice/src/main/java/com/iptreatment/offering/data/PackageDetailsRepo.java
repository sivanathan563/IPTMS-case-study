package com.iptreatment.offering.data;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.iptreatment.offering.entity.InPatientServicePackage;



@Repository
public interface PackageDetailsRepo extends JpaRepository<InPatientServicePackage, Integer>{

	InPatientServicePackage findByTreatmentPackageName(String treatmentPackageName);
	
}
