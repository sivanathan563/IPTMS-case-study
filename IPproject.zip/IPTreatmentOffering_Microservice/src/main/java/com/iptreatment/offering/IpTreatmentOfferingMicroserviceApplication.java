package com.iptreatment.offering;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IpTreatmentOfferingMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(IpTreatmentOfferingMicroserviceApplication.class, args);
	}

}
