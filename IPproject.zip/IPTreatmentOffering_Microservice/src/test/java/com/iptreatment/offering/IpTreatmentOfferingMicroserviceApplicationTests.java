package com.iptreatment.offering;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpTreatmentOfferingMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
