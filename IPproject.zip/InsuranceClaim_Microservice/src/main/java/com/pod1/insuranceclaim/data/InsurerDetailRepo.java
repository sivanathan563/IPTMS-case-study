package com.pod1.insuranceclaim.data;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pod1.insuranceclaim.entity.InsurerDetail;

@Repository
public interface InsurerDetailRepo extends JpaRepository<InsurerDetail, String>{
	
	@Query("FROM InsurerDetail where insurerPackageName = :packageName")
	InsurerDetail findByPackageName(String packageName);
	
	@Query("FROM InsurerDetail where insurerPackageName = :packageName and insurerName =:insurer")
	InsurerDetail findByPackageNameAndInsurer(@Param("packageName")String packageName,@Param("insurer")String insurer);

	
}