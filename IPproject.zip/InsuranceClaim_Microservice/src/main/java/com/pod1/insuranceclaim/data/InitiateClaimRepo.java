package com.pod1.insuranceclaim.data;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pod1.insuranceclaim.entity.InitiateClaim;

@Repository
public interface InitiateClaimRepo extends JpaRepository<InitiateClaim, String>{

}