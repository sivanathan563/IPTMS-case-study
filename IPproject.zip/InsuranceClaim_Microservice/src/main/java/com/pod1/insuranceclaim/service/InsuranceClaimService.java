package com.pod1.insuranceclaim.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pod1.insuranceclaim.client.AuthFeignClient;
import com.pod1.insuranceclaim.client.TreatmentFeignClient;
import com.pod1.insuranceclaim.data.InitiateClaimRepo;
import com.pod1.insuranceclaim.data.InsurerDetailRepo;
import com.pod1.insuranceclaim.entity.AuthResponse;
import com.pod1.insuranceclaim.entity.InitiateClaim;
import com.pod1.insuranceclaim.entity.InsuranceUpdateRequest;
import com.pod1.insuranceclaim.entity.InsurerDetail;
import com.pod1.insuranceclaim.exception.CustomException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class InsuranceClaimService {
	
	@Autowired
	InitiateClaimRepo initiateClaimRepo;
	
	@Autowired
	InsurerDetailRepo insurerDetailRepo;
	
	@Autowired
	TreatmentFeignClient treatmentFeign;
	
	@Autowired
	AuthFeignClient authFeign;
	
	
	//Writing method to find all Insurance Details in the database
	public List<InsurerDetail> findAll(String token) throws CustomException{
		AuthResponse auth=authFeign.getValidity(token);
		if(!auth.isValid())
		{
			throw new CustomException("Invalid User");
		}
		else if(!auth.getRole().equalsIgnoreCase("admin"))
		{
			throw new CustomException("Not Authorized");
		}
		return insurerDetailRepo.findAll();
	}
	
	//Writing Method to find Insurance Detail by the packageName
	public InsurerDetail findByPackageName(String packageName,final String token) throws CustomException {
		AuthResponse auth=authFeign.getValidity(token);
		if(!auth.isValid())
		{
			throw new CustomException("Invalid User");
		}
		else if(!auth.getRole().equalsIgnoreCase("admin"))
		{
			throw new CustomException("Not Authorized");
		}
		return insurerDetailRepo.findByPackageName(packageName);
	}
	
	//Creating method for the Admin to Initiate Claim
	/*Should Get the Price from the 2nd Micro Service and get the AmountLimit from
	 * This service and Deduct and display the result 
	 */
	public Double putInitiateClaim(InitiateClaim entity,final String token) throws CustomException    {
		AuthResponse auth=authFeign.getValidity(token);
		if(!auth.isValid())
		{
			throw new CustomException("Invalid User");
		}
		else if(!auth.getRole().equalsIgnoreCase("admin"))
		{
			throw new CustomException("Not Authorized");
		}
		
		String insurer = entity.getInsurerName();
		String packageName=entity.getInsurerPackageName();
		
		double cost=treatmentFeign.getCostDetail(entity.getPatientName(),token);
		
		entity.setCost(cost);
		
		InsurerDetail obj =insurerDetailRepo.findByPackageNameAndInsurer(packageName, insurer);
		log.info(obj.getInsurerPackageName());
		if(obj.getInsurerPackageName().equalsIgnoreCase(entity.getInsurerPackageName()))
		{
			initiateClaimRepo.save(entity);
		}
		else
		{
			throw new CustomException("No such insurance  package exist");
		} 
		
		double balance=cost*0.2;
		
		InsuranceUpdateRequest request =new InsuranceUpdateRequest();
		request.setBalance(balance);
		request.setPatientName(entity.getPatientName());
		request.setInsurerName(insurer);
		request.setInsurerPackageName(packageName);
		
		if(treatmentFeign.updateIpInsurance(request,token))
		{
			log.info("Patient Insurance Details Updated");
		}
		
		return balance;
	}
	
	
}