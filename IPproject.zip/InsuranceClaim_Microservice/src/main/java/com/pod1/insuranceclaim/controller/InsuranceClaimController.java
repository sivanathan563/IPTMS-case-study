package com.pod1.insuranceclaim.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.pod1.insuranceclaim.entity.InitiateClaim;
import com.pod1.insuranceclaim.entity.InsurerDetail;
import com.pod1.insuranceclaim.exception.CustomException;
import com.pod1.insuranceclaim.service.InsuranceClaimService;

@RestController
public class InsuranceClaimController {

	@Autowired
	InsuranceClaimService service;

	@GetMapping("/GetAllInsurerDetail")
	public List<InsurerDetail> getAllInsurerDetail(@RequestHeader("Authorization") final String token) throws CustomException {
		return service.findAll(token);
	}

	@GetMapping("/GetInsurerByPackageName/{packageName}")
	public InsurerDetail getInsurerByPackageName(@PathVariable("packageName")String packageName,@RequestHeader("Authorization") final String token) throws CustomException {
		return service.findByPackageName(packageName,token);
	}

	@PostMapping("/InitiateClaim")
	public Double initiateClaim(@RequestBody InitiateClaim entity,@RequestHeader("Authorization") final String token) throws CustomException {
		return service.putInitiateClaim(entity,token);
	}
}
