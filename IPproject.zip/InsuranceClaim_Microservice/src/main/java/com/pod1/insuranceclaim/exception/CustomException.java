package com.pod1.insuranceclaim.exception;

public class CustomException extends Exception {
	


	/**
	 * 
	 */
	private static final long serialVersionUID = 1111522452276357716L;

	public CustomException(String message) {
		super(message);
	}

}
