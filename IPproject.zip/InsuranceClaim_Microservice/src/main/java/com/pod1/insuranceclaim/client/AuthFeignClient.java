package com.pod1.insuranceclaim.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pod1.insuranceclaim.entity.AuthResponse;


@FeignClient(name="${feign.authapp.name}", url = "${feign.authapp.url}")
public interface AuthFeignClient {
	
	@RequestMapping(value = "/authapp/validate", method = RequestMethod.GET)
	AuthResponse getValidity(@RequestHeader("Authorization") final String token);
		

}
