package com.pod1.insuranceclaim.exception;

import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import feign.FeignException;

@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler
	public ResponseEntity<Object> handleCustomException(CustomException e) {

		HttpStatus status = HttpStatus.NOT_FOUND;

		ErrorResponse errors = new ErrorResponse(status.value(), e.getMessage());

		return new ResponseEntity<>(errors, status);
	}

	@ExceptionHandler
	public ResponseEntity<Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException e) {

		HttpStatus status = HttpStatus.BAD_REQUEST;

		ErrorResponse errors = new ErrorResponse();
		BindingResult result = e.getBindingResult();

		errors.setStatus(status.value());

		for (ObjectError err : result.getAllErrors()) {
			if (errors.getMessage() != null)
				errors.setMessage(errors.getMessage() + "[ " + err.getDefaultMessage() + " ]");
			else
				errors.setMessage("[ " + err.getDefaultMessage() + " ]");

		}

		return new ResponseEntity<>(errors, status);
	}

	@ExceptionHandler
	public ResponseEntity<Object> handleFeignException(FeignException e) {

		HttpStatus status = HttpStatus.BAD_REQUEST;
		ErrorResponse errors = new ErrorResponse();
		errors.setStatus(status.value());
		errors.setMessage("Feign client Response:"+e.contentUTF8());
		return ResponseEntity.status(status).body(errors);

	}



	@ExceptionHandler
	public ResponseEntity<Object> handleSQLIntegrityConstraintViolationException(
			SQLIntegrityConstraintViolationException e) {

		HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;

		ErrorResponse errors = new ErrorResponse();

		errors.setStatus(status.value());
		errors.setMessage(e.getMessage());

		return new ResponseEntity<>(errors, status);
	}
}
