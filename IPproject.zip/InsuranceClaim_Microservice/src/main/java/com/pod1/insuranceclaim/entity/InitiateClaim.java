package com.pod1.insuranceclaim.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class InitiateClaim {
	@Id
	private String patientName;
	private String ailement;
	private String treatmentPackageName;
	private String insurerName;
	private String insurerPackageName;
	private double cost;
}
