package com.pod1.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pod1.auth.models.Users;

@Repository
public interface UserRepository extends JpaRepository<Users, String> {

	Users findByUserName(String username);

	@Query(value = "select role from users where user_name=:username", nativeQuery = true)
	String getAuthority(String username);

	@Query(value = "SELECT user_id from users where user_name =:username ", nativeQuery = true)
	String findIdByUsername(String username);


}
