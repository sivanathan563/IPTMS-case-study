package com.pod1.auth.controller;

import java.sql.SQLIntegrityConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pod1.auth.models.AuthResponse;
import com.pod1.auth.models.UserRequest;
import com.pod1.auth.service.ControllerService;

@RestController
//@RequestMapping("/user")
public class UserLoginController {

	@Autowired
	ControllerService ctrlService;

	@Autowired
	public void createAdmin() throws SQLIntegrityConstraintViolationException {
		UserRequest admin = new UserRequest();
		admin.setEmail("admin@gmail.com");
		admin.setPassword("password");
		ctrlService.createAdmin(admin);
	}

	@PostMapping("/authenticate")
	public String login(@RequestBody UserRequest user) throws BadCredentialsException {
		return ctrlService.login(user);
	}
	
	@RequestMapping(value = "/validate", method = RequestMethod.GET)
	public AuthResponse getValidity(@RequestHeader("Authorization") final String token) {
		AuthResponse response = ctrlService.validate(token);
		System.out.println();
		return response;
	}
}
