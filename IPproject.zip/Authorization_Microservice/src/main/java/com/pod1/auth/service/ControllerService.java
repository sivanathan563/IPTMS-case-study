package com.pod1.auth.service;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.pod1.auth.models.AuthResponse;
import com.pod1.auth.models.UserRequest;
import com.pod1.auth.models.Users;
import com.pod1.auth.repository.UserRepository;
import com.pod1.auth.security.JwtUtil;

import lombok.extern.apachecommons.CommonsLog;

@Service
@CommonsLog
public class ControllerService {

	@Autowired
	UserRepository repo;

	@Autowired
	AuthenticationManager authenticationManager;

	@Autowired
	UsersService myUserDetails;

	@Autowired
	JwtUtil jwtUtil;

	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;

	public Users createAdmin(UserRequest userReq) throws SQLIntegrityConstraintViolationException {
		if (repo.findByUserName(userReq.getEmail()) != null) {
			throw new SQLIntegrityConstraintViolationException("User already exist with the given mail_ID");
		}

		Users user = new Users();
		user.setRole("admin");
		user.setUserId(UUID.randomUUID().toString());
		user.setPassword(bCryptPasswordEncoder.encode(userReq.getPassword()));
		user.setUserName(userReq.getEmail());
		log.info("Entering the create method");
		return repo.save(user);
	}

	public String login(UserRequest user) throws BadCredentialsException {
		myUserDetails.setRole(repo.getAuthority(String.valueOf(user.getEmail())));
		try {
			authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getEmail(), user.getPassword()));
		} catch (BadCredentialsException e) {
			throw new BadCredentialsException("Incorrect Username or password");
		}
		final UserDetails userDetails = myUserDetails.loadUserByUsername(String.valueOf(user.getEmail()));
		final String jwt = jwtUtil.generateToken(userDetails);
		log.info("JWT Token: " + jwt);
		return jwt;
	}
	


	public AuthResponse validate(String token) {
		AuthResponse authResponse = new AuthResponse();
	
		String jwt = token.substring(7);
		String username = jwtUtil.extractUsername(jwt);
		UserDetails userDetails = this.myUserDetails.loadUserByUsername(username);
		if (jwtUtil.validateToken(jwt,userDetails)) {
			authResponse.setUserName(jwtUtil.extractUsername(jwt));
			authResponse.setValid(true);
			authResponse.setRole(repo.findByUserName(jwtUtil.extractUsername(jwt)).getRole());
		} else {
			authResponse.setValid(false);
		}
		return authResponse;
	}
}
