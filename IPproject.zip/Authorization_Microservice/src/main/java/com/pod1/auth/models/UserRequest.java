package com.pod1.auth.models;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@ToString
public class UserRequest {
	@NotNull(message = "email cannot be null")
	@Email(message="provide valid email format e.g. abc@mail.com")
	@NotEmpty(message = "email cannot be Empty")
	private String email;
	
	@NotNull(message = "password cannot be null")
	@Size(min=8, max=16, message="Password must be equal or grater than 8 characters and less than 16 characters")
	@NotEmpty(message = "password cannot be Empty")
	private String password;

}
