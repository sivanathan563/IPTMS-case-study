package com.mfpe.iptm.iptreatment.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InuranceUpdateRequest {
	
	private String patientName;
	private String insurerName;
	private String insurerPackageName;
	private double balance; 
}
