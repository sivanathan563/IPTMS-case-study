package com.mfpe.iptm.iptreatment.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SpecialistDetail {

	private Integer specialistId;
	private String name;

	private String areaOfExpertise;

	private int experienceInYears;

	private long contactNumber;

}
