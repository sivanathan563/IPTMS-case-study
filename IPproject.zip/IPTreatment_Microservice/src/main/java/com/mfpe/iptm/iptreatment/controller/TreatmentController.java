package com.mfpe.iptm.iptreatment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.mfpe.iptm.iptreatment.entity.InuranceUpdateRequest;
import com.mfpe.iptm.iptreatment.entity.PatientDetail;
import com.mfpe.iptm.iptreatment.entity.TreatmentPlan;
import com.mfpe.iptm.iptreatment.exception.CustomException;
import com.mfpe.iptm.iptreatment.service.TreatmentService;

@RestController
public class TreatmentController {

	@Autowired
	TreatmentService treatmentService;
	
	@PostMapping("/FormulateTreatmentTimetable")
	public TreatmentPlan getTreatmentTimetable(@RequestBody PatientDetail patient,@RequestHeader("Authorization") final String token) throws CustomException{
		
		return treatmentService.getTreatmentByPatientDetails(patient,token);
	}
	
	@GetMapping("/IPCostDetail/{patientName}")
	public double getCostDetail(@PathVariable("patientName") String patientName,@RequestHeader("Authorization") final String token) throws CustomException
	{
		return treatmentService.getCostDetail(patientName,token);
	}
	
	@PostMapping("/IPInsuranceUpdate")
	public boolean updateIpInsurance(@RequestBody InuranceUpdateRequest insurance,@RequestHeader("Authorization") final String token) throws CustomException
	{
		return treatmentService.updateIpInsurance(insurance,token);
	}
	
}
