package com.mfpe.iptm.iptreatment.service;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mfpe.iptm.iptreatment.client.AuthFeignClient;
import com.mfpe.iptm.iptreatment.client.OfferingsFeignClient;
import com.mfpe.iptm.iptreatment.entity.AuthResponse;
import com.mfpe.iptm.iptreatment.entity.InPatientServicePackage;
import com.mfpe.iptm.iptreatment.entity.InuranceUpdateRequest;
import com.mfpe.iptm.iptreatment.entity.PatientDetail;
import com.mfpe.iptm.iptreatment.entity.PatientDetailEntry;
import com.mfpe.iptm.iptreatment.entity.SpecialistDetail;
import com.mfpe.iptm.iptreatment.entity.TreatmentPlan;
import com.mfpe.iptm.iptreatment.exception.CustomException;
import com.mfpe.iptm.iptreatment.repo.PatientDetailsEntryRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TreatmentService {

	@Autowired
	PatientDetailsEntryRepository patientRepo;

	@Autowired
	OfferingsFeignClient feign;
	
	@Autowired
	AuthFeignClient authFeign;

	public double getCostDetail(String patientName,final String token) throws CustomException {
		
		AuthResponse auth=authFeign.getValidity(token);
		if(!auth.isValid())
		{
			throw new CustomException("Invalid User");
		}
		else if(!auth.getRole().equalsIgnoreCase("admin"))
		{
			throw new CustomException("Not Authorized");
		}
		
		
		PatientDetailEntry patient =patientRepo.findByNameIgnoreCase(patientName);
		if(patient==null)
		{
			throw new CustomException("No patient exist with that id");
		}
		return patient.getCost();
	}
	
	public boolean updateIpInsurance(InuranceUpdateRequest insurance,final String token) throws CustomException
	{
		AuthResponse auth=authFeign.getValidity(token);
		if(!auth.isValid())
		{
			throw new CustomException("Invalid User");
		}
		else if(!auth.getRole().equalsIgnoreCase("admin"))
		{
			throw new CustomException("Not Authorized");
		}
		
		PatientDetailEntry patient =patientRepo.findByNameIgnoreCase(insurance.getPatientName());
		
		patient.setInsurerName(insurance.getInsurerName());
		patient.setInsurerPackageName(insurance.getInsurerPackageName());
		patient.setBalance(insurance.getBalance());
		patient=patientRepo.save(patient);
		
		if(patient.getName().equalsIgnoreCase(insurance.getPatientName()))
		{
			return false;
		}
		
		return true;
	}
	
	
	public TreatmentPlan getTreatmentByPatientDetails(PatientDetail patient,final String token) throws CustomException {
		
		log.info("Inside Patient Treatment Register Service");
		
		AuthResponse auth=authFeign.getValidity(token);
		if(!auth.isValid())
		{
			throw new CustomException("Invalid User");
		}
		else if(!auth.getRole().equalsIgnoreCase("admin"))
		{
			throw new CustomException("Not Authorized");
		}
		
		String treatmentPackageName = patient.getTreatmentPackageName();

		TreatmentPlan plan = new TreatmentPlan();

		PatientDetailEntry entry = new PatientDetailEntry();
		

		InPatientServicePackage patientPackage = feign.viewPackageByName(treatmentPackageName);
		SpecialistDetail specialist = feign.getSpecialistByPackage(treatmentPackageName);

		LocalDate treatmentStart = patient.getCommencementDate();
		int duration = patientPackage.getTreatmentduration();
		int durationInDays = duration * 7;
		LocalDate treatmentEnd = treatmentStart.plusDays(durationInDays);

		plan.setTreatmentEndDate(treatmentEnd);
		plan.setTestDetails(patientPackage.getTestdetails());
		plan.setTreatmentCommencementDate(treatmentStart);
		plan.setPackageName(treatmentPackageName);
		plan.setCost(patientPackage.getCost());
		plan.setSpecialist(specialist.getName());

		entry.setName(patient.getName());
		entry.setAge(patient.getAge());
		entry.setAilment(patient.getAilment());
		entry.setTreatmentPackageName(treatmentPackageName);
		entry.setTestDetails(patientPackage.getTestdetails());
		entry.setCost(patientPackage.getCost());
		entry.setSpecialist(specialist.getName());
		entry.setTreatmentCommencementDate(treatmentStart);
		entry.setTreatmentEndDate(treatmentEnd);
		entry.setTreatmentStatus("In Progress");
		entry.setPayment("Pending");

		patientRepo.save(entry);

		return plan;
	}
	
	
	
	
	
	
}
