package com.mfpe.iptm.iptreatment.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.mfpe.iptm.iptreatment.entity.InPatientServicePackage;
import com.mfpe.iptm.iptreatment.entity.SpecialistDetail;



@FeignClient(name="${feign.offerings.name}", url = "${feign.offerings.url}")
public interface OfferingsFeignClient {
	
	@GetMapping("/offerings/IPTreatmentPackageByName/{packageName}")
	InPatientServicePackage viewPackageByName(@PathVariable("packageName") String packageName);
	
	@GetMapping("/offerings/IPSpecialist/{packageName}")
	SpecialistDetail getSpecialistByPackage(@PathVariable("packageName")String packageName);
}
