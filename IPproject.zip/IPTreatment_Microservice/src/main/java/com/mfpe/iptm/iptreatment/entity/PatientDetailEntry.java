package com.mfpe.iptm.iptreatment.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class PatientDetailEntry {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer patientId;
	private String name;
	private int age;
	private String ailment;
	private String treatmentPackageName;
	private String testDetails;
	private double cost;
	private String specialist;
	private LocalDate treatmentCommencementDate;
	private LocalDate treatmentEndDate;
	private String treatmentStatus;
	private String insurerName;
	private String insurerPackageName;
	private double balance;
	private String payment;
	

}
