package com.mfpe.iptm.iptreatment.entity;



import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TreatmentPlan {


	private String packageName;
	private String testDetails;
	private double cost;
	private String specialist;
	private LocalDate treatmentCommencementDate;
	private LocalDate treatmentEndDate;
	
	
	
}
 