package com.mfpe.iptm.iptreatment.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class InPatientServicePackage {
	

	private Integer packageId;
	
	private String ailmentCategory;

	private String treatmentPackageName;

	private String testdetails;

	private double cost;
	
	private int treatmentduration;

}
