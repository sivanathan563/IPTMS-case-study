package com.mfpe.iptm.iptreatment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpTreatmentMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
